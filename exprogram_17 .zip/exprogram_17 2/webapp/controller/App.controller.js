sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("exam.exprogram17.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  